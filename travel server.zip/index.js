const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')

require('dotenv').config()


const { MongoClient } = require('mongodb');

const uri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASS}@cluster0.msjpp.mongodb.net/${process.env.DB_NAME}?retryWrites=true&w=majority`;


const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });


const app = express()
app.use(cors())
app.use(bodyParser.json())


client.connect(err => {

    const collection = client.db("travel-friend").collection("tour-data")

    app.post('/tourdata', (req, res) => {
        console.log(req.body)
        //collection.insertOne(req.body)
        res.send("post")
    })

    app.post('/newtour', (req, res) => {
        console.log(req.body)
    })


    app.get('/data', (req, res) => {
        collection.find({})
            .toArray((err, document) => {
                res.send(document)
                //console.log(document)
            })


    })



    app.get('/data/:id', (req, res) => {

        const data = collection.find({ id: req.params.id })
            .toArray((err, document) => {
                res.send(document)
            })
    })

















});






app.get("/", (req, res) => {
    console.log("sexy")
    res.send("sexy");
})


app.listen(5000, () => {
    console.log("app started");


})



